#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, return the value that was passed in
    if (i < 0 || i >= 3) {
        printf("That's not a valid index.\n");
        return 1;
    }

    // If the index is within the bounds of the array, return the value
    // Otherwise, return the value that was passed in
    if (i == 0) {
        printf("You can't use index 0.\n");
        return 1;
    }

    // If the index is not within the bounds of the array, return the value
    // Otherwise, return the value that was passed in
    if (i!= 0 && i!= 1 && i!= 2) {
        printf("That's not a valid index.\n");
        return 1;
    }

    // If the index is not within the bounds of the array, return the value
    // Otherwise, return the value that was passed in
    if (i!= 0 && i!= 1 && i!= 2) {
        printf("That's not a valid index.\n");
        return 1;
    }

    // If the index is not within the bounds of the array, return the value
}
