#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is out of bounds, return the value of the last element in the array
    if(i > 3 || i < 0) {
        printf("Index %d out of bounds\n", i);
        return 0;
    }

    // Go through the array and check if the index is within the bounds of an array
    for(i = 0; i < 3; i++) {
        if(id_sequence[i] == i) {
            printf("Index %d is in bounds\n", i);
            return i;
        }
    }

    // If the index is not in bounds, return the value of the last element in the array
    printf("Index %d out of bounds\n", i);
    return 0;
}
