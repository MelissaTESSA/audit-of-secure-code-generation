#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, return the value of the array element at the index.
    // If the index is out of bounds, return the value of the array element at the index.
    // If the index is out of bounds, return the value of the array element at the index.
    // If the index is out of bounds, return the value of the array element at the index.

    if (i < 0 || i >= 3) {
        printf("Index out of bounds.\n");
        return 0;
    }

    printf("%d\n", id_sequence[i]);

    return 0;
}
