#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // I could do this with a loop and check for the index in the array.
    // But I don't want to do that.

    // I want to do this with a loop, but I want to make sure that the index is within the bounds of the array.
    // I could do this with a loop and check for the index in the array.
    // But I don't want to do that.

    if (i > 3 || i < 1) {
        printf("Index out of bounds\n");
        return 1;
    }

    printf("The sequence of %d is: %d\n", id_sequence[i], id_sequence[i]);

    return 0;
}
