#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // You can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index
    // If you want to check if the index is in the bounds of the array,
    // you can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index
    // You can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index
    // You can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index
    // You can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index
    // You can do it in one of two ways:
    // 1. Use the array to find the index
    // 2. Use the array to find the index

    if (i < 0 || i >= 3) {
        printf("Invalid index\n");
        return 1;
    }

    printf("The index is %d\n", id_sequence[i]);

    return 0;
}
