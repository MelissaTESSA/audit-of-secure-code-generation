#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // This is a good way to check if the index is within the bounds of an array.
    // If it is not, the function will return the value of the index.
    if (i < 0 || i >= 3) {
        printf("Index out of bounds.\n");
        return 0;
    }

    // This is the function to return the value of the index.
    return id_sequence[i];
}
