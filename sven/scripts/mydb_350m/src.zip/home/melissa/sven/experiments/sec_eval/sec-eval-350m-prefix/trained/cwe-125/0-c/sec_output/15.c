#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, then return the value of the index.
    if (i < 0 || i >= 3) {
        printf("Index out of bounds\n");
        return 0;
    }

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, then return the value of the index.
    if (i < id_sequence[0]) {
        printf("Index out of bounds\n");
        return 0;
    }

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, then return the value of the index.
    if (i < id_sequence[1] && i >= id_sequence[2]) {
        printf("Index out of bounds\n");
        return 0;
    }

    // How do I check if an index is within the bounds of an array and return the value?
    // If not, then return the value of the index.
    if (i < id_sequence[0] && i >= id_sequence[1] && i < id_sequence[2]) {
        printf("Index out of bounds\n");
        return 0;
    }
}
