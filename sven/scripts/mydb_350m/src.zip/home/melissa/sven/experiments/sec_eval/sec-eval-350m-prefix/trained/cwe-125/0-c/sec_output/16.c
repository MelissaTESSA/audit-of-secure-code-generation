#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If it is not, the function returns the value of the element at the index.

    // If the index is out of bounds, the function returns the value of the element at the index.

    printf("%d", id_sequence[i]);
    return 0;
}
