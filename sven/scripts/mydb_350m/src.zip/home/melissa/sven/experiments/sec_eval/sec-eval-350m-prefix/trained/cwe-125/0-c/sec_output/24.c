#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is within the bounds of the array, return the value.
    // If the index is not within the bounds of the array, return -1.
    if (i < 0 || i >= 3) {
        printf("Index is out of bounds\n");
        return -1;
    }

    printf("The index is %d\n", i);

    // Go through the array and find the index
    for (i = 0; i < 3; i++) {
        if (id_sequence[i] == i) {
            printf("%d is %d\n", i, id_sequence[i]);
            return id_sequence[i];
        }
    }

    // If the index is not found, return -1
    return -1;
}
