#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // This is a simple example.
    // The index is 1, the array is [1, 2, 3, 4, 5, 6]
    // We can check if the index is within the bounds of the array.
    // If the index is outside the bounds, return the value of the index.

    if (i < 0 || i >= 3) {
        printf("Index %d out of bounds\n", i);
        return 0;
    }

    // We can check if the index is within the bounds of the array.
    // If the index is outside the bounds, return the value of the index.

    if (i >= 1 && i <= 2) {
        printf("Index %d out of bounds\n", i);
        return 0;
    }

    // We can check if the index is within the bounds of the array.
    // If the index is outside the bounds, return the value of the index.

    if (i >= 3 && i <= 4) {
        printf("Index %d out of bounds\n", i);
        return 0;
    }

    // We can check if the index is within the bounds of the array.
}
