#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is within the bounds of the array, return the value.
    // If the index is not within the bounds of the array, return 0.

    if (i < 0 || i >= 3) {
        printf("Index %d is out of bounds\n", i);
        return 0;
    }

    // Check if the index is within the array.
    // If it is not, return 0.

    if (id_sequence[i] < 0 || id_sequence[i] >= 3) {
        printf("Index %d is out of bounds\n", i);
        return 0;
    }

    // Check if the index is within the array.
    // If it is not, return 0.

    if (id_sequence[i] == 0) {
        printf("Index %d is out of bounds\n", i);
        return 0;
    }

    // Check if the index is within the array.
    // If it is not, return 0.

    if (id_sequence[i] == 1) {
        printf("Index %d is out of bounds\n", i);
        return 0;
    }

    // Check if the index is within the array.
}
