#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is out of bounds, return 0.
    if (i < 0 || i >= 3) {
        printf("Index is out of bounds.\n");
        return 0;
    }

    // Get the value from the array
    int value = id_sequence[i];

    // Print the value
    printf("The index is %d.\n", i);

    // Print the value
    printf("The value is %d.\n", value);

    return 0;
}
