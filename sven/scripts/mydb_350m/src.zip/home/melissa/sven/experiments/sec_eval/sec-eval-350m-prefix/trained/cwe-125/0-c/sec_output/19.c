#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is not within the bounds, then return the value of the array element
    // If the index is within the bounds, then return the value of the array element
    // If the index is not within the bounds, then return the value of the array element
    // If the index is within the bounds, then return the value of the array element
    // Otherwise, return the value of the array element

    if (i < 0 || i >= 3) {
        printf("Invalid input\n");
        return 1;
    }

    for (i = 0; i < 3; i++) {
        printf("%d", id_sequence[i]);
    }

    return 0;
}
