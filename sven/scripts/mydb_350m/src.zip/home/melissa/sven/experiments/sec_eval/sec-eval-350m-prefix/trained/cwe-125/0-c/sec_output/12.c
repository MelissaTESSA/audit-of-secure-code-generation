#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is outside the array, return the value 0.
    // If the index is within the array, return the value 1.

    if (i < 0 || i >= 3) {
        printf("Index %d out of bounds.\n", i);
        return 0;
    }

    // The index is within the array, so return 1.
    if (i == 0) {
        printf("Index %d is 0.\n", i);
        return 1;
    }

    // The index is not within the array, so return 0.
    if (i == 1) {
        printf("Index %d is 1.\n", i);
        return 0;
    }

    // The index is not within the array, so return 0.
    if (i == 2) {
        printf("Index %d is 2.\n", i);
        return 0;
    }

    // The index is not within the array, so return 0.
    if (i == 3) {
        printf("Index %d is 3.\n", i);
        return 0;
    }
}
