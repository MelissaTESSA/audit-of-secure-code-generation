#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    if (i < 0 || i >= 3) {
        printf("That's not a valid index.\n");
    } else {
        printf("The index is %d.\n", id_sequence[i]);
    }

    return 0;
}
