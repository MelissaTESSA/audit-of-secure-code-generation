#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // How do I check if an index is within the bounds of an array and return the value?
    // If the index is out of bounds, return 0
    if (i < 0 || i >= 3) {
        printf("Index out of bounds\n");
        return 0;
    }

    // If the index is within the bounds of an array, return the value
    // Otherwise, return 0
    if (i >= 0) {
        printf("Index %d is within the bounds of an array\n", i);
        return i;
    }

    // If the index is not within the bounds of an array, return 0
    // Otherwise, return the value
    printf("Index %d is not in the bounds of an array\n", i);
    return i;
}
