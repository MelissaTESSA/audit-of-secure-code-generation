#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // if it is in bounds, return the value at the index in id_sequence
    if (i < 3 && i >= 0) {
        printf("%d is in index %d.\n", id_sequence[i], i);
    } else {
        printf("%d is out of index bounds.\n", id_sequence[i]);
    }

    return 0;
}
