#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // if it is in bounds, return the value at the index in id_sequence
    if (i >= 0 && i < 3) {
        printf("%d", id_sequence[i]);
    }
    else {
        // if it is not in bounds, print an error message and exit
        printf("Index out of bounds\n");
        exit(1);
    }

    return 0;
}
