#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int id_sequence[3] = {1, 5, 7};
    int i;

    printf("Enter the index value: ");
    scanf("%d", &i);

    // if it is in bounds, return the value at the index in id_sequence
    if (i >= 0 && i < 3) {
        printf("%d is the value at index %d\n", id_sequence[i], i);
    } else {
        // otherwise, return -1
        printf("%d is out of bounds\n", i);
    }

    return 0;
}
